# Zendo's Personal Portfolio

A beginner-friendly personal portfolio website built with HTML and CSS.

## Files
- `index.html` — the complete portfolio website.

## Run locally
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Create a public repository on GitHub (for example, `zendo-portfolio`).
2. Upload `index.html` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then save.
6. Wait for GitHub Pages to publish the site.
